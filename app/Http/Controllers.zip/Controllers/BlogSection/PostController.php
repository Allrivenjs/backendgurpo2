<?php

namespace App\Http\Controllers\BlogSection;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PostController extends Controller
{
    //
}
